import os

import pandas as pd
from flask import Blueprint, current_app, jsonify, render_template, request, send_file

from services.processor import build_insights, process_single


main_blueprint = Blueprint("main", __name__)


def get_insights_store():
    return current_app.extensions["insights_store"]


@main_blueprint.route("/")
def index():
    return render_template("index.html")


@main_blueprint.route("/assets/<path:filename>")
def assets(filename):
    return send_file(os.path.join(current_app.config["ASSETS_DIR"], filename))


@main_blueprint.route("/process", methods=["POST"])
def process():
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "No files uploaded"}), 400
    if len(files) > 10:
        return jsonify({"error": "Maximum 10 files allowed"}), 400

    results = []
    for file in files:
        output_path, error = process_single(file, file.filename, current_app.config["OUTPUT_DIR"])
        if error:
            results.append({"filename": file.filename, "error": error})
            continue
        output_filename = os.path.basename(output_path)
        get_insights_store()[output_filename] = output_path
        results.append({"filename": file.filename, "output_filename": output_filename, "error": None})
    return jsonify(results)


@main_blueprint.route("/process-combined", methods=["POST"])
def process_combined():
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "No files uploaded"}), 400
    if len(files) > 5:
        return jsonify({"error": "Maximum 5 files allowed"}), 400

    for directory in (current_app.config["OUTPUT_DIR"], current_app.config["SPLIT_DIR"]):
        for filename in os.listdir(directory):
            path = os.path.join(directory, filename)
            if os.path.isfile(path):
                os.remove(path)
    get_insights_store().clear()

    results = []
    for file in files:
        try:
            dataframe = read_uploaded_file(file)
        except Exception as error:
            results.append({"filename": file.filename, "error": f"Could not read file: {error}"})
            continue

        menu_item_column = next((column for column in dataframe.columns if "Menu Item" in str(column)), None)
        if menu_item_column is None:
            results.append({"filename": file.filename, "error": "Menu Item column not found"})
            continue

        dataframe[menu_item_column] = dataframe[menu_item_column].astype(str).str.strip()
        menu_items = [item for item in dataframe[menu_item_column].unique() if item and item.lower() != "nan"]
        for item in menu_items:
            split_filename = f"{item}.csv"
            split_path = os.path.join(current_app.config["SPLIT_DIR"], split_filename)
            dataframe[dataframe[menu_item_column] == item].to_csv(split_path, index=False, encoding="utf-8", lineterminator="\n")
            with open(split_path, "rb") as split_file:
                output_path, error = process_single(split_file, split_filename, current_app.config["OUTPUT_DIR"])
            if error:
                results.append({"filename": split_filename, "error": error})
                continue
            output_filename = os.path.basename(output_path)
            get_insights_store()[output_filename] = output_path
            results.append({"filename": split_filename, "output_filename": output_filename, "error": None})
    return jsonify(results)


@main_blueprint.route("/download/<output_filename>")
def download(output_filename):
    path = os.path.join(current_app.config["OUTPUT_DIR"], output_filename)
    if not os.path.exists(path):
        return "File not found", 404
    return send_file(path, mimetype="text/csv", as_attachment=True, download_name=output_filename)


@main_blueprint.route("/insights/<output_filename>")
def insights(output_filename):
    path = get_insights_store().get(output_filename)
    if not path or not os.path.exists(path):
        return jsonify({"error": "No output file found"}), 400
    return jsonify(build_insights(path))


def read_uploaded_file(file):
    if file.filename.lower().endswith(".csv"):
        dataframe = pd.read_csv(file, dtype=str, low_memory=False, keep_default_na=False)
    else:
        dataframe = pd.read_excel(file, dtype=str).fillna("")
    dataframe.columns = dataframe.columns.str.strip()
    return dataframe