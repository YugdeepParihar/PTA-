import os

from flask import Flask

from routes.main import main_blueprint


BASE_DIR = os.path.dirname(__file__)


def create_app():
    app = Flask(__name__)
    app.config.update(
        OUTPUT_DIR=os.path.join(BASE_DIR, "Output"),
        SPLIT_DIR=os.path.join(BASE_DIR, "Split"),
        ASSETS_DIR=os.path.join(BASE_DIR, "Assets"),
    )
    for directory in (app.config["OUTPUT_DIR"], app.config["SPLIT_DIR"]):
        os.makedirs(directory, exist_ok=True)
    app.extensions["insights_store"] = {}
    app.register_blueprint(main_blueprint)
    return app


app = create_app()


if __name__ == "__main__":
    app.run(debug=True)