const allowedExtensions = ['.xlsx', '.xls', '.xlsm', '.csv'];
let selectedFiles = [];

const dropZone = document.getElementById('dropZoneSplit');
const fileInput = document.getElementById('fileInputSplit');
const processButton = document.getElementById('processBtnSplit');
const status = document.getElementById('statusSplit');

function showModal(title, body) {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML = body;
  document.getElementById('modalOverlay').classList.add('show');
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('show');
}

function renderFileList() {
  document.getElementById('fileListSplit').innerHTML = selectedFiles.map((file, index) => `
    <div class="file-row" style="margin-top:${index === 0 ? 14 : 0}px">
      <span>&#128196; ${file.name}</span>
      <button class="remove-btn" data-file-index="${index}">&#10005;</button>
    </div>`).join('');
  document.querySelectorAll('[data-file-index]').forEach(button => {
    button.addEventListener('click', () => {
      selectedFiles.splice(Number(button.dataset.fileIndex), 1);
      renderFileList();
    });
  });
  document.getElementById('fileCountSplit').textContent = selectedFiles.length ? `${selectedFiles.length} / 5 file(s) selected` : '';
  processButton.disabled = selectedFiles.length === 0;
  document.getElementById('summarySection').style.display = 'none';
  document.getElementById('tabBar').innerHTML = '';
  document.getElementById('tabPanels').innerHTML = '';
  status.textContent = '';
}

function addFiles(files) {
  const existingFiles = new Set(selectedFiles.map(file => file.name));
  const rejectedFiles = [];
  for (const file of files) {
    const extension = '.' + file.name.split('.').pop().toLowerCase();
    if (!allowedExtensions.includes(extension)) {
      rejectedFiles.push(file.name);
    } else if (selectedFiles.length >= 5) {
      showModal('Limit Reached', 'You can upload a maximum of <strong>5 files</strong> at a time.');
      break;
    } else if (!existingFiles.has(file.name)) {
      selectedFiles.push(file);
      existingFiles.add(file.name);
    }
  }
  if (rejectedFiles.length) {
    showModal('Invalid File(s)', `<strong>Wrong format</strong> (only .xlsx, .xls, .xlsm, .csv):<br>${rejectedFiles.map(name => '&bull; ' + name).join('<br>')}`);
  }
  renderFileList();
}

function switchTab(id) {
  document.querySelectorAll('.tab-btn').forEach(button => button.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
  document.getElementById('tab-btn-' + id).classList.add('active');
  document.getElementById('tab-panel-' + id).classList.add('active');
}

function buildPanel(filename, insights) {
  const discrepancies = !insights.discrepancies || !insights.discrepancies.length
    ? '<div class="disc-item ok">&#9989; No discrepancies found</div>'
    : insights.discrepancies.map(item => `<div class="disc-item"><strong>${item.type}</strong> (${item.count} affected)</div>`).join('');
  return `<div class="stat-grid"><div class="stat-box blue"><div class="val">${insights.total_stores}</div><div class="lbl">Total Stores</div></div><div class="stat-box green"><div class="val">${insights.active}</div><div class="lbl">Active</div></div><div class="stat-box red"><div class="val">${insights.inactive}</div><div class="lbl">Inactive</div></div><div class="stat-box orange"><div class="val">${insights.active_pct}%</div><div class="lbl">Active %</div></div></div><div class="section-title">&#128269; Discrepancy Checks</div>${discrepancies}<a class="dl-btn" href="/download/${encodeURIComponent(filename)}" download>&#11015;&#65039; Re-download ${filename}</a>`;
}

function buildFullDescription(items) {
  const averagePercentage = (items.reduce((sum, item) => sum + item.data.active_pct, 0) / items.length).toFixed(1);
  const rows = items.map(({ filename, data }) => `<tr><td>${filename.replace(/\.csv$/, '')}</td><td>${data.total_stores}</td><td>${data.active}</td><td>${data.inactive}</td><td>${data.active_pct}%</td></tr>`).join('');
  return `<div class="section-title">&#128202; MI Comparison Table</div><div style="overflow-x:auto"><table class="fd-table"><thead><tr><th>MI</th><th>Total Stores</th><th>Active</th><th>Inactive</th><th>Active %</th></tr></thead><tbody>${rows}</tbody></table></div><div class="avg-box">&#11088; Average Active %: ${averagePercentage}%<span>across ${items.length} MI(s)</span></div>`;
}

async function renderResults(results) {
  const tabBar = document.getElementById('tabBar');
  const tabPanels = document.getElementById('tabPanels');
  tabBar.innerHTML = '';
  tabPanels.innerHTML = '';
  const allInsights = [];
  for (let index = 0; index < results.length; index++) {
    const result = results[index];
    const tabId = 'tab' + index;
    const isError = Boolean(result.error);
    const button = document.createElement('button');
    button.className = 'tab-btn' + (index === 0 ? ' active' : '') + (isError ? ' error' : '');
    button.id = 'tab-btn-' + tabId;
    button.textContent = (isError ? 'Error: ' : 'File: ') + (result.output_filename ? result.output_filename.replace(/\.csv$/, '') : result.filename);
    button.onclick = () => switchTab(tabId);
    tabBar.appendChild(button);

    const panel = document.createElement('div');
    panel.className = 'tab-panel' + (index === 0 ? ' active' : '');
    panel.id = 'tab-panel-' + tabId;
    if (isError) {
      panel.innerHTML = '<div class="error-msg">&#10060; ' + result.error + '</div>';
    } else {
      const response = await fetch('/insights/' + encodeURIComponent(result.output_filename));
      const insights = await response.json();
      panel.innerHTML = buildPanel(result.output_filename, insights);
      allInsights.push({ filename: result.output_filename, data: insights });
    }
    tabPanels.appendChild(panel);
  }
  if (allInsights.length) {
    const tabId = 'tabFullDesc';
    const button = document.createElement('button');
    button.className = 'tab-btn';
    button.id = 'tab-btn-' + tabId;
    button.textContent = 'Full Description';
    button.onclick = () => switchTab(tabId);
    tabBar.appendChild(button);
    const panel = document.createElement('div');
    panel.className = 'tab-panel';
    panel.id = 'tab-panel-' + tabId;
    panel.innerHTML = buildFullDescription(allInsights);
    tabPanels.appendChild(panel);
  }
  document.getElementById('summarySection').style.display = 'block';
}

document.getElementById('modalClose').addEventListener('click', closeModal);
document.getElementById('modalOverlay').addEventListener('click', event => {
  if (event.target === event.currentTarget) closeModal();
});
dropZone.addEventListener('click', () => fileInput.click());
dropZone.addEventListener('dragover', event => { event.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', event => { event.preventDefault(); dropZone.classList.remove('dragover'); addFiles(Array.from(event.dataTransfer.files)); });
fileInput.addEventListener('change', () => { addFiles(Array.from(fileInput.files)); fileInput.value = ''; });
processButton.addEventListener('click', async () => {
  if (!selectedFiles.length) return;
  processButton.disabled = true;
  status.innerHTML = '<span class="spinner"></span> Splitting &amp; processing...';
  const formData = new FormData();
  selectedFiles.forEach(file => formData.append('files', file));
  try {
    const response = await fetch('/process-combined', { method: 'POST', body: formData });
    const results = await response.json();
    if (!response.ok) {
      status.textContent = 'Error: ' + (results.error || 'Server error');
      return;
    }
    for (const result of results) {
      if (!result.error) {
        const link = document.createElement('a');
        link.href = '/download/' + encodeURIComponent(result.output_filename);
        link.download = result.output_filename;
        link.click();
        await new Promise(resolve => setTimeout(resolve, 400));
      }
    }
    status.textContent = `Done! ${results.filter(result => !result.error).length} file(s) downloaded.`;
    await renderResults(results);
  } catch (error) {
    status.textContent = 'Error: ' + error.message;
  } finally {
    processButton.disabled = false;
  }
});